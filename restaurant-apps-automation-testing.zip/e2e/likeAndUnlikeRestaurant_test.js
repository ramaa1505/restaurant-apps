Feature('Like and Unlike Restaurant');

Scenario('Open Restaurant List Page', ({ I }) => {
  I.amOnPage('/'); // Buka halaman utama aplikasi
  I.seeElement('.restaurant-item'); // Pastikan elemen restoran ada
});


  